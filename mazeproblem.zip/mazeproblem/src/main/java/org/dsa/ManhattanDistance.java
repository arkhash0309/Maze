package org.dsa;

public class ManhattanDistance {


    public static void main(String[] args) {
        // Example usage:
        int[] node8 = {2, 3};  // Coordinates of node 8
        int[] goalNode = {5, 7};  // Coordinates of the goal node

//        int heuristicCost8 = calculateManhattanDistance(node8, goalNode);
//        System.out.println("Heuristic cost for node 8: " + heuristicCost8);
    }
}

