package org.dsa;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Stack;

public class MazeDFSWithGUI extends JFrame {
    private static final int rows = 6;
    private static final int columns = 6;
    private static final int cellSize = 60;

    private static final char[][] maze = createMaze();
    private static final Node startNode = new Node(2, 1);
    private static final Node goalNode = new Node(3, 4);

    private static final int[][] moves = {
            {-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
    };

    private static Stack<Node> dfsStack = new Stack<>();
    private static ArrayList<Node> visitedNodes = new ArrayList<>();

    public MazeDFSWithGUI() {
        setTitle("Maze DFS GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(rows, columns));

        displayMaze();
        // Use a separate thread to start DFS after a delay
        new Thread(() -> {
            try {
                Thread.sleep(2000); // Adjust the delay time as needed (2 seconds in this example)
                performDFS();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
//
//        JButton startButton = new JButton("Start DFS");
//        startButton.addActionListener(e -> performDFS());
//
//        JPanel buttonPanel = new JPanel();
//        buttonPanel.add(startButton);
//        add(buttonPanel);

        pack();
        setLocationRelativeTo(null); // Center the frame
        setVisible(true);
    }

    private static char[][] createMaze() {
        // Initialize the maze with cell numbers starting from 0 at (1, 1)
        int cellNumber = 0;
        char[][] maze = new char[rows][columns];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                maze[i][j] = Character.forDigit(cellNumber++, 10);
            }
        }

        // Set the starting node to (2, 3)
        int startX = 2;
        int startY = 1;
        maze[startX][startY] = 'S';

        // Set the goal node to (3, 4)
        int goalX = 3;
        int goalY = 4;
        maze[goalX][goalY] = 'G';

        // Set barrier nodes at specific positions
        maze[0][1] = 'B';
        maze[1][3] = 'B';
        maze[1][5] = 'B';

        maze[4][3] = 'B';

        return maze;
    }

    private void displayMaze() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                JLabel cellLabel = new JLabel(String.valueOf(maze[i][j]), SwingConstants.CENTER);
                cellLabel.setOpaque(true);
                cellLabel.setPreferredSize(new Dimension(cellSize, cellSize));

                if (maze[i][j] == 'S') {
                    cellLabel.setBackground(Color.PINK); // Rose color for the starting node
                } else if (maze[i][j] == 'G') {
                    cellLabel.setBackground(Color.GREEN); // Green color for the goal node
                } else if (maze[i][j] == 'B') {
                    cellLabel.setBackground(Color.GRAY); // Gray color for barrier nodes
                } else {
                    cellLabel.setBackground(Color.WHITE); // Default color for other nodes
                }

                cellLabel.setBorder(new LineBorder(Color.BLACK)); // Set black border for all cells

                add(cellLabel);
            }
        }
    }

    private void performDFS() {
        dfsStack.clear();
        visitedNodes.clear();

        dfsStack.push(startNode);

        while (!dfsStack.isEmpty()) {
            Node currentNode = dfsStack.pop();

            if (currentNode.equals(goalNode)) {
                highlightVisitedNodes();
                return;
            }

            if (!visitedNodes.contains(currentNode)) {
                visitedNodes.add(currentNode);

                for (int[] move : moves) {
                    int newRow = currentNode.getRow() + move[0];
                    int newCol = currentNode.getCol() + move[1];

                    if (isValidMove(newRow, newCol)) {
                        dfsStack.push(new Node(newRow, newCol));
                        highlightVisitedNodes();
                        sleep(500); // Add a delay for better visualization (adjust as needed)
                    }
                }
            }
        }
    }

    private boolean isValidMove(int row, int col) {
        return row >= 0 && row < rows && col >= 0 && col < columns && maze[row][col] != 'B';
    }

    private void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void highlightVisitedNodes() {
        SwingUtilities.invokeLater(() -> {
            Component[] components = getContentPane().getComponents();
            int index = 0;

            for (Node node : visitedNodes) {
                JLabel cellLabel = (JLabel) components[index++];
                cellLabel.setBackground(Color.BLUE);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MazeDFSWithGUI());
    }

    static class Node {
        private final int row;
        private final int col;

        public Node(int row, int col) {
            this.row = row;
            this.col = col;
        }

        public int getRow() {
            return row;
        }

        public int getCol() {
            return col;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            Node node = (Node) obj;
            return row == node.row && col == node.col;
        }

        @Override
        public int hashCode() {
            return 31 * row + col;
        }
    }
}
