package org.dsa;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;


public class MazeGUI extends JFrame {
    private static final int rows = 6;
    private static final int columns = 6;
    private static final int cellSize = 60;
    private final String[][] maze = createMaze();



    private static final int[][] moves = {
            {-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
    };
    private static final Stack<String> dfsStack = new Stack<>();
    private static final ArrayList<String> visitedNodes = new ArrayList<>();

    public MazeGUI() {
        setTitle("Maze GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(rows, columns));

        String[][] maze = createMaze();
        displayMaze(maze);

        new Thread(() -> {
            try {
                Thread.sleep(2000);
                performDFS();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private String[][] createMaze() {
        int cellNumber = 0;
        String[][] maze = new String[rows][columns];
        for (int i = 0; i < columns; i++) {
            for (int j = 0; j < rows; j++) {
                maze[j][i] = Integer.toString(cellNumber);
                cellNumber++;

                if (cellNumber > 35) {
                    cellNumber = 0;
                }
            }
        }

        int startX = 2;
        int startY = 1;
        maze[startX][startY] = String.valueOf('S');

        int goalX = 3;
        int goalY = 4;
        maze[goalX][goalY] = String.valueOf('G');

        maze[0][1] = String.valueOf('B');
        maze[1][3] = String.valueOf('B');
        maze[1][5] = String.valueOf('B');
        maze[4][3] = String.valueOf('B');



        return maze;
    }

    private void displayMaze(String[][] maze) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                JLabel cellLabel = new JLabel(String.valueOf(maze[i][j]), SwingConstants.CENTER);
                cellLabel.setOpaque(true);
                cellLabel.setPreferredSize(new Dimension(cellSize, cellSize));

                if (String.valueOf("S").equals(maze[i][j])) {
                    cellLabel.setBackground(Color.PINK);
                } else if (String.valueOf('G').equals(maze[i][j])) {
                    cellLabel.setBackground(Color.GREEN);
                } else if (String.valueOf('B').equals(maze[i][j])) {
                    cellLabel.setBackground(Color.GRAY);
                } else {
                    cellLabel.setBackground(Color.WHITE);
                }

                cellLabel.setBorder(new LineBorder(Color.BLACK));
                add(cellLabel);
            }
        }
    }

    private void performDFS() {

        dfsStack.clear();
        visitedNodes.clear();

        int startX = 2;
        int startY = 1;
        dfsStack.push(maze[startX][startY]);

        while (!dfsStack.isEmpty()) {
            String currentNode = dfsStack.pop();
            visitedNodes.add(currentNode);

            if (currentNode.equals("G")) {
                System.out.println("Goal node found!");
                break;
            }

            int row = Arrays.stream(maze).flatMap(Arrays::stream).toList().indexOf(currentNode) / columns;
            int col = Arrays.stream(maze).flatMap(Arrays::stream).toList().indexOf(currentNode) % columns;

            for (int[] move : moves) {
                int nextRow = row + move[0];
                int nextCol = col + move[1];

                if (isValidMove(nextRow, nextCol)) {
                    dfsStack.push(maze[nextRow][nextCol]);
                }
            }

            sleep(1000);
            highlightVisitedNodes();
        }
    }

    private boolean isValidMove(int row, int col) {
        return row >= 0 && row < rows && col >= 0 && col < columns && !maze[row][col].equals("B");
    }

    private void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void highlightVisitedNodes() {
        SwingUtilities.invokeLater(() -> {
            Component[] components = getContentPane().getComponents();
            int index = 0;
            for (String node : visitedNodes) {

                index = Arrays.stream(maze).flatMap(Arrays::stream).toList().indexOf(node);
                JLabel cellLabel = (JLabel) components[index];
                cellLabel.setBackground(Color.BLUE);

            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MazeGUI());
    }
}
